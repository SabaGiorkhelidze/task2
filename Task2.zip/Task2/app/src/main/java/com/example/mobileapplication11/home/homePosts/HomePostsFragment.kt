package com.example.MobileApp.home.homePosts

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.MobileApp.adapters.HighlightsAdapter
import com.example.MobileApp.adapters.PostsAdapter
import com.example.MobileApp.databinding.FragmentHomePostsBinding
import com.example.MobileApp.models.Highlights
import com.example.MobileApp.models.Post

class HomeFeedFragment : Fragment() {

    private lateinit var binding: FragmentHomePostsBinding
    private lateinit var postAdapter: PostsAdapter
    private lateinit var highlightAdapter: HighlightsAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentHomePostsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupPostRecyclerView()
        setupHighlightRecyclerView()
    }

    private fun setupHighlightRecyclerView() = with(binding) {
        rvStories.layoutManager = LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, false)
        highlightAdapter = HighlightsAdapter()
        rvStories.adapter = highlightAdapter

        val highlights = listOf(
            Highlights("", "friend1"),
            Highlights("", "friend2"),
            Highlights("", "friend3"),
            Highlights("", "friend4"),
            Highlights("", "friend1"),
            Highlights("", "friend2"),
            Highlights("", "friend3"),
            Highlights("", "friend4")
        )
        highlightAdapter.submitList(highlights)
    }

    private fun setupPostRecyclerView() = with(binding) {
        rvHomePosts.layoutManager = LinearLayoutManager(activity)
        postAdapter = PostsAdapter()
        rvHomePosts.adapter = postAdapter

        val posts = listOf(
            Post("", "user293487", "London, England", ""),
            Post("", "user51", "Paris, France", ""),
            Post("", "kjawbhv", "Tbilisi, Georgia", ""),
            Post("", "sfljb", "London, England", ""),
            Post("", "user293487", "London, England", ""),
            Post("", "user51", "Paris, France", ""),
            Post("", "kjawbhv", "Tbilisi, Georgia", ""),
            Post("", "sfljb", "London, England", ""),
            Post("", "user293487", "London, England", ""),
            Post("", "user51", "Paris, France", ""),
            Post("", "kjawbhv", "Tbilisi, Georgia", ""),
            Post("", "sfljb", "London, England", "")
        )

        postAdapter.submitList(posts)
    }

    companion object {
        @JvmStatic
        fun newInstance() = HomeFeedFragment()
    }
}
