package com.example.MobileApp.models

data class Highlights(
    val storyImage : String,
    val text : String
)
