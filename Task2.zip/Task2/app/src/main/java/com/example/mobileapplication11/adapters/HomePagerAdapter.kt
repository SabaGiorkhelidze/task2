package com.example.MobileApp.home

import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.MobileApp.fragment.HomePostsFragment
import com.example.MobileApp.fragment.StoriesFragment

class MainPagerAdapter(parentFragment: Fragment) : FragmentStateAdapter(parentFragment) {

    override fun getItemCount(): Int = PAGE_COUNT

    override fun createFragment(index: Int): Fragment = when (index) {
        STORIES_PAGE -> StoriesFragment()
        POSTS_PAGE -> HomePostsFragment()
        else -> error("Invalid page index: $index")
    }

    companion object {
        private const val PAGE_COUNT = 2
        private const val STORIES_PAGE = 0
        private const val POSTS_PAGE = 1
    }
}
