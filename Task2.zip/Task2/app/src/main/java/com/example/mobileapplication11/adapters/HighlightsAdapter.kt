package com.example.MobileApp.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.MobileApp.R
import com.example.MobileApp.databinding.ItemStoryBinding
import com.example.MobileApp.models.Highlights

class HighlightsListAdapter : ListAdapter<Highlights, HighlightsListAdapter.ViewHolder>(HighlightDiffCallback()) {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val binding: ItemStoryBinding = ItemStoryBinding.bind(itemView)
        
        fun bindData(highlight: Highlights) {
            binding.tvHText.text = highlight.text
        }
    }

    class HighlightDiffCallback : DiffUtil.ItemCallback<Highlights>() {
        override fun areItemsTheSame(oldItem: Highlights, newItem: Highlights): Boolean = oldItem == newItem

        override fun areContentsTheSame(oldItem: Highlights, newItem: Highlights): Boolean = oldItem == newItem
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_story, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindData(getItem(position))
    }
}