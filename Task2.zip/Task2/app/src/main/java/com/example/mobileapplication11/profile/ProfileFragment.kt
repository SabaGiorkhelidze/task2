package com.example.MobileApp.profile

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.MobileApp.databinding.FragmentProfileBinding
import com.example.MobileApp.models.Highlights
import com.example.MobileApp.adapters.HighlightsAdapter
import com.example.MobileApp.adapters.ViewPagerAdapter
import com.example.MobileApp.profile.profileFragments.UserPostsFragment
import com.example.MobileApp.profile.profileFragments.UserTaggedFragment
import com.google.android.material.tabs.TabLayoutMediator

class UserProfileFragment : Fragment() {

    private lateinit var binding: FragmentProfileBinding
    private lateinit var highlightsAdapter: HighlightsAdapter

    private val fragmentList = listOf(
        UserPostsFragment.newInstance(),
        UserTaggedFragment.newInstance()
    )

    private val tabTitles = listOf("Posts", "Tagged")

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupViewPager()
        setupRecyclerView()
    }

    private fun setupRecyclerView() = with(binding) {
        rvHighlights.layoutManager =
            LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, false)
        highlightsAdapter = HighlightsAdapter()
        rvHighlights.adapter = highlightsAdapter

        val highlightsList = listOf(
            Highlights("", "Highlight 1"),
            Highlights("", "Highlight 2"),
            Highlights("", "Highlight 3"),
            Highlights("", "Highlight 1"),
            Highlights("", "Highlight 2"),
            Highlights("", "Highlight 3"),
            Highlights("", "Highlight 1"),
            Highlights("", "Highlight 2"),
            Highlights("", "Highlight 3")
        )

        highlightsAdapter.submitList(highlightsList)
    }

    private fun setupViewPager() = with(binding) {
        val pagerAdapter = ViewPagerAdapter(activity as FragmentActivity, fragmentList)
        viewPager.adapter = pagerAdapter
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = tabTitles[position]
        }.attach()
    }

    companion object {
        @JvmStatic
        fun newInstance() = UserProfileFragment()
    }
}
