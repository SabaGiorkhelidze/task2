package com.example.MobileApp.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.viewpager2.widget.ViewPager2
import com.example.MobileApp.R
import com.example.MobileApp.home.HomePagerAdapter

class DashboardFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val fragmentView = inflater.inflate(R.layout.fragment_home, container, false)
        val viewPager: ViewPager2 = fragmentView.findViewById(R.id.homeViewPager)
        viewPager.adapter = HomePagerAdapter(this)

        return fragmentView
    }
}
