package com.example.MobileApp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.MobileApp.fragments.HomeFragment

class DashboardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.fragmentContainer, HomeFragment.newInstance())
            .commit()
    }
}
