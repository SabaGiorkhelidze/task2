package com.example.MobileApp.models

data class Post(
    val userAvatar : String,
    val userName: String,
    val location: String,
    val postItem: String
)
